# DESI OFFICIALS — Commerce backend upgrade kit

This is a Cloudflare Workers + D1 + R2 backend package for the existing DO storefront. It is designed to keep **Unique DOs bidding** and add normal shopping orders, UPI/COD checkout, member accounts, paid memberships, a private admin area, order email alerts and numeric image-gallery sorting.

## Important before deployment

The currently published website (`do-desiofficials.desioficials.workers.dev`) is a different, newer design than the V2 starter ZIP available in the earlier project files. This package therefore includes the V2 storefront only as `public/storefront-demo.html` for reference and does **not** overwrite the currently published site. Merge the `/api` routes and `public/member-experience.js` into the current site's Worker/frontend, or provide the current site's source ZIP so the integration can be merged without losing its existing layout, Unique DOs section, account modal, cart or UPI QR screen.

Do not publish the demo storefront over the live site as a shortcut.

## Included

- `src/index.js` — Worker API: account registration/login/logout, profile, products, orders, UPI/COD selection, memberships, Unique DO auctions/bids, admin endpoints, R2 uploads, gallery listing.
- `migrations/0001_init.sql` — D1 schema.
- `public/admin.html` — private order/product/image/membership control room.
- `public/member-experience.js` — personalised signed-in greeting and member styling hook.
- `public/storefront-api.js` — same-origin JavaScript helpers for connecting the existing cart, login, membership and bidding UI to the backend.
- `wrangler.toml` — Worker bindings template.
- `public/storefront-demo.html` — previous V2 storefront reference, not the current live design.

## Cloudflare resources

Create a D1 database named `desi-officials-db` and an R2 bucket named `desi-officials-media`. Update `database_id` in `wrangler.toml` with the real D1 ID. Keep the binding names `DB`, `MEDIA` and `ASSETS` consistent.

Install Wrangler on a computer with Node.js, then from this folder run:

```bash
npm install --save-dev wrangler
npx wrangler d1 create desi-officials-db
npx wrangler r2 bucket create desi-officials-media
npx wrangler d1 migrations apply desi-officials-db --remote
```

If you created the D1 database with the CLI, paste the returned database ID into `wrangler.toml` before applying migrations/deploying. For first deployment:

```bash
npx wrangler secret put ADMIN_EMAIL
npx wrangler secret put ADMIN_PASSWORD
npx wrangler secret put UPI_ID
npx wrangler secret put UPI_PAYEE_NAME
npx wrangler secret put RESEND_API_KEY
npx wrangler secret put MAIL_FROM
npx wrangler deploy
```

Use a long, unique admin password. `MAIL_FROM` must be a sender/domain verified with Resend. The store notification recipient is fixed to `desiofficials26@gmail.com` by default. `RESEND_API_KEY` is required for email notifications; without it, orders are still saved in D1 but no email is sent. Never put secrets in HTML or browser JavaScript.

For local development, run `npx wrangler dev`. For production, set the secrets in the production Worker environment. The Worker should be integrated into the **same origin** as the storefront so its secure, HttpOnly session cookies work with `credentials: same-origin`.

## UPI and COD behaviour

- UPI: the API returns a UPI payment URI if `UPI_ID` is configured. The order stays `PENDING` until you verify the payment in your bank/UPI app and mark it paid in the admin dashboard. This avoids trusting a screenshot or a client-side success message.
- COD: the order is recorded with payment method `COD` and payment status `PENDING`.
- Membership plans: ₹99 / 1 month, ₹499 / 6 months, ₹999 / 1 year. Membership remains pending until you verify the UPI payment and activate it from Admin.
- No payment gateway/webhook is configured in this first phase. Do not mark an order paid until the payment is actually visible in your account.

## Admin

After deploying, visit `/admin`. Sign in using the `ADMIN_EMAIL` and `ADMIN_PASSWORD` Worker secrets. You can review orders/customer delivery details, update fulfilment/payment statuses, add/update products, upload images and verify membership payments.

## Image upload naming

Upload images through Admin using names such as `7.jpg`, `8.png`, `9.webp`, `10.jpg`, `11.png`. The API extracts the leading number and stores a numeric sort key, so `10.jpg` follows `9.webp` instead of appearing between `1` and `2`. Supported formats: JPG, PNG, WEBP, AVIF and GIF; maximum 8 MB per file. The public gallery API is `GET /api/gallery`.

## Storefront API contract

- `POST /api/register` — `{name,email,phone,password}` (password minimum 10 characters)
- `POST /api/login` — `{email,password}`
- `POST /api/logout`
- `GET /api/me`
- `GET /api/products`
- `POST /api/orders` — `{name,email,phone,pincode,address,payment_method:'UPI'|'COD',items:[{product_id,size,quantity}]}`
- `POST /api/memberships` — `{plan_code:'monthly'|'six_months'|'annual',payment_reference?}`
- `GET /api/auctions`
- `POST /api/auctions/:id/bids` — `{amount}` (signed-in members only)
- `GET /api/gallery`

All prices are calculated server-side from the D1 product catalogue; never send a trusted total from the browser. Populate real product rows and stock before enabling checkout. Product IDs in the cart must match the IDs stored in D1.

## Existing site integration checklist

1. Back up/export the currently deployed Worker source and assets first.
2. Merge this Worker API into the current Worker script, retaining its current HTML/CSS/JS and Unique DO bidding UI. The API must run on the same origin (`/api/*`).
3. Add the member experience script after the current site's scripts, or merge its logic into the existing account/login code.
4. Load `storefront-api.js` on the existing site and use `DOStore` helpers for login, profile, membership and auction actions. Replace the current checkout's demo/local-only handler with `DOStore.order(...)` / `POST /api/orders`; send line items by product ID, selected size and quantity. Use the response's `upi.url` for UPI payment, and display the COD confirmation for COD orders.
5. Seed the D1 `products` table with your real catalogue, actual prices, actual sizes and stock. The sample products in the old starter are not verified products.
6. Preserve the existing auction interface and connect it to `/api/auctions` and `/api/auctions/:id/bids`.
7. Test a test customer account, order, email alert, COD order, UPI URI, membership approval, bid and numbered image upload before accepting real orders.

## Security / production notes

- Admin access uses a separate eight-hour HttpOnly session and Worker secrets.
- Customer passwords are PBKDF2-SHA-256 hashed with per-user random salts; passwords are never stored in plaintext.
- Session tokens are stored hashed in D1 and issued as Secure, HttpOnly, SameSite=Lax cookies.
- Uploads are restricted by MIME type and 8 MB size. Review every uploaded file before publishing it.
- This is a first implementation kit, not a substitute for a full security review, privacy policy, terms, shipping/returns policy, tax review or production payment reconciliation.
- The current API sends the store notification via Resend. Verify your sender domain and test delivery before launch.
