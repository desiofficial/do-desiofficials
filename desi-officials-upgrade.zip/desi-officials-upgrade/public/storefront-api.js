/* DESI OFFICIALS storefront integration helpers.
   Load on the same origin as the Worker API. No API keys belong in this file. */
window.DOStore = (() => {
  async function request(path, options = {}) {
    const isForm = options.body instanceof FormData;
    const response = await fetch(`/api${path}`, {
      credentials: "same-origin",
      ...options,
      headers: { ...(isForm ? {} : { "content-type": "application/json" }), ...(options.headers || {}) }
    });
    const data = await response.json();
    if (!response.ok || data.ok === false) throw new Error(data.error || "Request failed");
    return data;
  }
  return {
    register: details => request("/register", { method:"POST", body:JSON.stringify(details) }),
    login: credentials => request("/login", { method:"POST", body:JSON.stringify(credentials) }),
    logout: () => request("/logout", { method:"POST", body:"{}" }),
    me: () => request("/me"),
    products: () => request("/products"),
    gallery: () => request("/gallery"),
    auctions: () => request("/auctions"),
    bid: (auctionId, amount) => request(`/auctions/${encodeURIComponent(auctionId)}/bids`, { method:"POST", body:JSON.stringify({amount}) }),
    order: details => request("/orders", { method:"POST", body:JSON.stringify(details) }),
    membership: details => request("/memberships", { method:"POST", body:JSON.stringify(details) })
  };
})();
