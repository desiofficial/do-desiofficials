/* Store settings. Set your business WhatsApp number before using checkout.
   Format: country code + number, digits only. Example for India: 919876543210
   Leave blank until you are ready to receive real customer enquiries.
*/
window.STORE_CONFIG = {
  whatsappNumber: "",
  currency: "INR",
  storeName: "DESI OFFICIALS"
};
