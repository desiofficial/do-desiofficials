/* Add this file to the existing DESI OFFICIALS storefront after its main script.
   It adds a lightweight personalised member greeting/theme using the secure session cookie. */
(async function DOExperience(){
  const API = "/api"; // Keep the API on the same origin as the storefront.
  const $ = id => document.getElementById(id);
  try {
    const response = await fetch(`${API}/me`, { credentials:"same-origin" });
    if (!response.ok) return; // Visitors who are not signed in see the regular storefront.
    const data = await response.json();
    if (!data.ok || !data.user) return;
    document.documentElement.classList.add("do-member-mode");
    document.documentElement.dataset.doMember = data.user.member_id;
    const greeting = document.createElement("div");
    greeting.className = "do-member-greeting";
    greeting.setAttribute("role","status");
    greeting.textContent = `WELCOME BACK, ${data.user.name.toUpperCase()} · ${data.user.member_id}`;
    const target = document.querySelector("header") || document.body;
    target.appendChild(greeting);
    const style = document.createElement("style");
    style.textContent = `.do-member-greeting{padding:9px 16px;background:#c7f36b;color:#111;text-align:center;font:700 10px/1.4 system-ui;letter-spacing:.16em}.do-member-mode{--do-member-accent:#c7f36b}`;
    document.head.appendChild(style);
    if (data.membership?.payment_status === "PAID" && data.membership.expires_at && Date.parse(data.membership.expires_at)>Date.now()) {
      document.documentElement.classList.add("do-paid-member");
      greeting.textContent += " · MEMBER ACCESS ACTIVE";
    }
  } catch (error) { console.warn("DO member greeting unavailable", error); }
})();
