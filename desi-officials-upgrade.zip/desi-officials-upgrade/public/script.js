const products = [
  {id:101,name:"Off-Duty Oversized Tee",category:"men",type:"T-SHIRT",price:799,oldPrice:999,badge:"BESTSELLER",image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=85",sizes:["S","M","L","XL","XXL"],description:"A relaxed everyday silhouette designed for repeat wears. Sample catalogue item — replace with your actual product and fabric details."},
  {id:102,name:"After Hours Graphic Tee",category:"unisex",type:"GRAPHIC TEE",price:899,oldPrice:1099,badge:"NEW DROP",image:"https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=900&q=85",sizes:["S","M","L","XL","XXL"],description:"A statement graphic tee concept with an easy streetwear fit. Sample catalogue item — artwork and product photography need to be replaced."},
  {id:103,name:"Everyday Essential Shirt",category:"women",type:"RELAXED SHIRT",price:1199,oldPrice:1499,badge:"DO FAVOURITE",image:"https://images.unsplash.com/photo-1598554747436-c9293d6a588f?auto=format&fit=crop&w=900&q=85",sizes:["XS","S","M","L","XL"],description:"An easy layer for everyday styling. Add your exact material, fit, care and size information before publishing for sale."},
  {id:104,name:"Utility Cargo Trousers",category:"men",type:"BOTTOMS",price:1499,oldPrice:1799,badge:"TRENDING",image:"https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=900&q=85",sizes:["28","30","32","34","36"],description:"A utility-inspired style concept. Replace this editorial image and sample description with an accurate image and specification of the real item."},
  {id:105,name:"Off-Grid Crop Tee",category:"women",type:"CROP TEE",price:699,oldPrice:899,badge:"JUST IN",image:"https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=900&q=85",sizes:["XS","S","M","L","XL"],description:"A clean casual essential with a contemporary shape. Confirm garment measurements and available sizes before selling."},
  {id:106,name:"Weekend Club Hoodie",category:"unisex",type:"HOODIE",price:1699,oldPrice:1999,badge:"LIMITED EDIT",image:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=85",sizes:["S","M","L","XL","XXL"],description:"A cosy layer for cooler days. This is a sample listing, not a stock or availability claim."},
  {id:107,name:"Everyday Denim Layer",category:"women",type:"DENIM",price:1899,oldPrice:2299,badge:"DO SELECT",image:"https://images.unsplash.com/photo-1543076447-215ad9ba6923?auto=format&fit=crop&w=900&q=85",sizes:["XS","S","M","L","XL"],description:"A denim-inspired wardrobe layer. Update this sample with correct construction details, wash, fit and care information."},
  {id:108,name:"Core Logo Tee",category:"sale",type:"CORE TEE",price:599,oldPrice:799,badge:"SALE",onSale:true,image:"https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=900&q=85",sizes:["S","M","L","XL","XXL"],description:"A sample core tee listing to demonstrate sale pricing. Do not use the sample price until your real costs and margins are calculated."}
];

const currency = n => new Intl.NumberFormat("en-IN", {style:"currency", currency:"INR", maximumFractionDigits:0}).format(n);
const $ = id => document.getElementById(id);
let currentFilter = "all";
let activeProduct = null;
let activeSize = "";
let cart = JSON.parse(localStorage.getItem("do-store-cart") || "[]");
let wishlist = JSON.parse(localStorage.getItem("do-store-wishlist") || "[]");

function filteredProducts(){
  let list = [...products];
  if(currentFilter !== "all") list = list.filter(p => p.category === currentFilter || (currentFilter === "sale" && p.onSale));
  const term = $("searchInput").value.trim().toLowerCase();
  if(term) list = list.filter(p => `${p.name} ${p.type} ${p.category}`.toLowerCase().includes(term));
  const sort = $("sortSelect").value;
  if(sort === "low") list.sort((a,b)=>a.price-b.price);
  if(sort === "high") list.sort((a,b)=>b.price-a.price);
  return list;
}

function renderProducts(){
  const list = filteredProducts();
  $("productGrid").innerHTML = list.length ? list.map(p => `
    <article class="product-card">
      <div class="product-image" data-product="${p.id}" role="button" tabindex="0" aria-label="View ${p.name}">
        <img src="${p.image}" alt="Sample fashion image for ${p.name}" loading="lazy" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(145deg,#d6d2c8,#a7aa9b)';">
        <span class="product-badge">${p.badge}</span>
        <button class="heart-button ${wishlist.includes(p.id)?"active":""}" data-wish="${p.id}" aria-label="${wishlist.includes(p.id)?"Remove from":"Add to"} wishlist">${wishlist.includes(p.id)?"♥":"♡"}</button>
        <button class="quick-button" data-quick="${p.id}">QUICK VIEW + SELECT SIZE</button>
      </div>
      <div class="product-info"><div><h3 class="product-name">${p.name}</h3><p class="product-subtitle">${p.type} · ${p.category.toUpperCase()}</p></div><div class="product-price">${p.oldPrice?`<span class="old-price">${currency(p.oldPrice)}</span>`:""}${currency(p.price)}</div></div>
    </article>`).join("") : `<div class="no-results">NO MATCHES THIS TIME. TRY ANOTHER SEARCH.</div>`;
}

function setFilter(filter){
  currentFilter = filter;
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.filter===filter));
  renderProducts();
  $("mobileNav").classList.remove("open");
}

function openQuickView(id){
  activeProduct = products.find(p=>p.id===Number(id));
  if(!activeProduct) return;
  activeSize = "";
  $("quickImage").style.backgroundImage = `url("${activeProduct.image}")`;
  $("quickCategory").textContent = `DESI OFFICIALS / ${activeProduct.type}`;
  $("quickName").textContent = activeProduct.name;
  $("quickPrice").textContent = `${currency(activeProduct.price)}${activeProduct.oldPrice?`   ${currency(activeProduct.oldPrice)}`:""}`;
  $("quickDescription").textContent = activeProduct.description;
  $("sizeOptions").innerHTML = activeProduct.sizes.map(size=>`<button type="button" data-size="${size}">${size}</button>`).join("");
  $("sizeError").classList.remove("show");
  $("quickView").classList.add("show");
  $("overlay").classList.add("show");
  document.body.classList.add("no-scroll");
}
function closeQuickView(){ $("quickView").classList.remove("show"); $("overlay").classList.remove("show"); document.body.classList.remove("no-scroll"); }
function saveCart(){localStorage.setItem("do-store-cart",JSON.stringify(cart));renderCart();}
function addToCart(){
  if(!activeProduct) return;
  if(!activeSize){$("sizeError").classList.add("show");return;}
  const existing=cart.find(x=>x.id===activeProduct.id && x.size===activeSize);
  if(existing) existing.qty += 1; else cart.push({id:activeProduct.id,size:activeSize,qty:1});
  saveCart();closeQuickView();openCart();
}
function changeQty(id,size,amount){
  const row=cart.find(x=>x.id===id && x.size===size);
  if(!row)return;
  row.qty += amount;
  if(row.qty <= 0) cart=cart.filter(x=>!(x.id===id && x.size===size));
  saveCart();
}
function removeCartItem(id,size){cart=cart.filter(x=>!(x.id===id && x.size===size));saveCart();}
function renderCart(){
  const count=cart.reduce((sum,row)=>sum+row.qty,0);
  $("bagCount").textContent=count;
  $("drawerCount").textContent=`(${count})`;
  const total=cart.reduce((sum,row)=>sum+(products.find(p=>p.id===row.id)?.price||0)*row.qty,0);
  $("subtotal").textContent=currency(total);
  $("cartItems").innerHTML=cart.length?cart.map(row=>{
    const p=products.find(x=>x.id===row.id);if(!p)return "";
    return `<div class="cart-row"><img src="${p.image}" alt="" onerror="this.style.visibility='hidden'"><div><h3>${p.name}</h3><p>SIZE: ${row.size}</p><span class="row-price">${currency(p.price*row.qty)}</span><div class="quantity"><button data-qty="-1" data-id="${p.id}" data-size="${row.size}" aria-label="Decrease quantity">−</button><span>${row.qty}</span><button data-qty="1" data-id="${p.id}" data-size="${row.size}" aria-label="Increase quantity">+</button></div></div><button class="remove-item" data-remove="${p.id}" data-size="${row.size}">REMOVE</button></div>`;
  }).join(""):`<div class="empty-bag"><span>DO</span><p>Your bag is taking a breather.</p><small>Good things belong in here.</small></div>`;
}
function openCart(){$("cartDrawer").classList.add("show");$("overlay").classList.add("show");document.body.classList.add("no-scroll");}
function closeCart(){$("cartDrawer").classList.remove("show");$("overlay").classList.remove("show");document.body.classList.remove("no-scroll");}
function toggleWishlist(id){const n=Number(id);wishlist=wishlist.includes(n)?wishlist.filter(x=>x!==n):[...wishlist,n];localStorage.setItem("do-store-wishlist",JSON.stringify(wishlist));renderProducts();}

$("categoryTabs").addEventListener("click",e=>{const btn=e.target.closest("[data-filter]");if(btn)setFilter(btn.dataset.filter);});
document.querySelectorAll("[data-category-link]").forEach(link=>link.addEventListener("click",()=>setFilter(link.dataset.categoryLink)));
$("sortSelect").addEventListener("change",renderProducts);
$("productGrid").addEventListener("click",e=>{
  const wish=e.target.closest("[data-wish]");if(wish){e.stopPropagation();toggleWishlist(wish.dataset.wish);return;}
  const quick=e.target.closest("[data-quick]");if(quick){openQuickView(quick.dataset.quick);return;}
  const card=e.target.closest("[data-product]");if(card)openQuickView(card.dataset.product);
});
$("productGrid").addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&e.target.matches("[data-product]")){e.preventDefault();openQuickView(e.target.dataset.product);}});
$("sizeOptions").addEventListener("click",e=>{const b=e.target.closest("[data-size]");if(!b)return;activeSize=b.dataset.size;document.querySelectorAll("[data-size]").forEach(x=>x.classList.toggle("selected",x===b));$("sizeError").classList.remove("show");});
$("quickAdd").addEventListener("click",addToCart);
$("quickClose").addEventListener("click",closeQuickView);
$("bagOpen").addEventListener("click",openCart);
$("bagClose").addEventListener("click",closeCart);
$("overlay").addEventListener("click",()=>{closeQuickView();closeCart();});
$("cartItems").addEventListener("click",e=>{const q=e.target.closest("[data-qty]");const r=e.target.closest("[data-remove]");if(q)changeQty(Number(q.dataset.id),q.dataset.size,Number(q.dataset.qty));if(r)removeCartItem(Number(r.dataset.remove),r.dataset.size);});
$("checkoutButton").addEventListener("click",()=>{
  if(!cart.length){alert("Your bag is empty.");return;}
  const phone=(window.STORE_CONFIG?.whatsappNumber||"").replace(/\D/g,"");
  if(phone.length<10){alert("The store is still being set up. The owner must add a business WhatsApp number in config.js before checkout enquiries can be sent.");return;}
  const rows=cart.map(row=>{const p=products.find(x=>x.id===row.id);return `${p.name} | Size ${row.size} | Qty ${row.qty} | ${currency(p.price*row.qty)}`;});
  const total=cart.reduce((sum,row)=>sum+products.find(p=>p.id===row.id).price*row.qty,0);
  const message=`Hello DESI OFFICIALS, I would like to enquire about these items:\n\n${rows.join("\n")}\n\nSubtotal: ${currency(total)}\nPlease confirm current stock, final price, shipping and payment options.`;
  window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`,"_blank","noopener");
});
$("searchOpen").addEventListener("click",()=>{$("searchPanel").classList.toggle("open");if($("searchPanel").classList.contains("open"))$("searchInput").focus();});
$("searchClose").addEventListener("click",()=>{$("searchPanel").classList.remove("open");$("searchInput").value="";renderProducts();});
$("searchInput").addEventListener("input",renderProducts);
$("menuOpen").addEventListener("click",()=>$("mobileNav").classList.toggle("open"));
$("newsletterForm").addEventListener("submit",e=>{e.preventDefault();$("newsletterMessage").textContent="Thanks! Newsletter sign-up will be connected when the store backend is ready.";$("newsletterEmail").value="";});
document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeQuickView();closeCart();$("mobileNav").classList.remove("open");}});
$("year").textContent=new Date().getFullYear();
renderProducts();renderCart();
